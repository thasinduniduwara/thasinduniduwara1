start luajit.exe clib.txt








